#include <stdio.h>
#include <stdlib.h>

int main()
{
    typedef struct{
    int dia,mes,anio;
    }eFecha;
    typedef struct{
    char nombre[21];
    int legajo;
    float sueldo;
    char sexo;
    eFecha fn;
    }eEmpleado;

    int main(){
    eEmpleado emp;
    emp.nombre;
    emp.legajo;
    emp.fn.dia;
    }
}
