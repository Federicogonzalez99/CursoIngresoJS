#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED

unsigned int verifica(void);

#endif // FUNCIONES_H_INCLUDED

